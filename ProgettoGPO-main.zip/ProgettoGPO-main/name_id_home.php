username_login

password_login

remember_login

submit_login


nome_register

cognome_register

giorno_register

mese_register

anno_register

username_register

email_register

telefono_register

password_register

passwordConf_register